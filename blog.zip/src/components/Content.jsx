import React from 'react'
import { RiHotelLine } from "react-icons/ri";
import { GiSchoolBag } from "react-icons/gi";
import { TbBuildingStore } from "react-icons/tb";
import { GiHealthCapsule } from "react-icons/gi";
import { TbCarSuv } from "react-icons/tb";
export default function Content() {
  return (
    <div>
         <div className='flex h-[160px] justify-between  px-[100px] m-[0,auto]  '>
            <div className=' border h-[170px] w-[205px] mt-[-90px] bg-white text-center hover:bg-[#ff545a]  shadow-lg shadow-gray-500/50 '>
                <TbBuildingStore className='h-[70px] w-[80px] m-auto my-4'/>
                <h3>Resturent</h3>
                <p className='text-[#a09e9c] '>150 listings</p>
            </div>
            <div className='border h-[170px] w-[205px] mt-[-90px] bg-white text-center hover:bg-[#ff545a]  shadow-lg shadow-gray-500/50'>
                <GiSchoolBag className='h-[70px] w-[80px] m-auto my-4'/>
                <h3>Destination</h3>
                <p className='text-[#a09e9c]'>214 listings</p>
            </div>
            <div className='border h-[170px] w-[205px] mt-[-90px] bg-white text-center hover:bg-[#ff545a]  shadow-lg shadow-gray-500/50'>
                <RiHotelLine className='h-[70px] w-[80px] m-auto my-4'/>
                <h3>Hotels</h3>
                <p className='text-[#a09e9c]'>185 listings</p>
            </div>
            <div className='border h-[170px] w-[205px] mt-[-90px] bg-white text-center hover:bg-[#ff545a]  shadow-lg shadow-gray-500/50'>
                <GiHealthCapsule className='h-[70px] w-[80px] m-auto my-4'/>
                <h3>Healthcare</h3>
                <p className='text-[#a09e9c]'>200 listings</p>
            </div>
            <div className='border h-[170px] w-[205px] mt-[-90px] bg-white text-center hover:bg-[#ff545a]  shadow-lg shadow-gray-500/50'>
                <TbCarSuv className='h-[70px] w-[80px] m-auto my-4'/>
                <h3>Automotion</h3>
                <p className='text-[#a09e9c]'>150 listings</p>
            </div>
           
        </div>
    </div>
  )
}
