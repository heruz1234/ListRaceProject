import React from 'react'

export default function 
() {
  return (
    <div className='my-10 text-center mb-28 '>
        <h1 className=' py-4 text-2xl text-gray-600'>NEWS AND ARTICLES</h1>
        <p>Always upto date with our latest News and Articles</p>
        <div className='flex flex-wrap text-left justify-between px-28 mt-10'>
            <div className='border w-[360px] shadow-lg hover:shadow-gray-500/50 shadow-black-500/50'>
                <img src="/public/Image/b1.jpg" alt="" />
                <div className='w-[350px] p-8'>
                    <h2>How to find your Desired Place more quickly</h2>
                    <div className='flex text-gray-400 py-3'>
                        <p className=' pr-5 border border-y-0 border-l-0'>Posted By <span className='text-black'>ADMIN</span></p>
                        <p className='pl-5'> March 2018 </p>
                    </div>
                    <p className='text-gray-400'>Lorem ipsum dolor sit amet, consectetur de adipisicing elit, sed do eiusmod tempore incididunt ut labore et dolore magna.</p>
                </div>
            </div>
            <div className='border w-[360px] shadow-lg hover:shadow-gray-500/50 shadow-black-500/50'>
                <img src="/public/Image/b2.jpg" alt="" />
                <div className='w-[350px] p-8'>
                    <h2>How to find your Desired Place more quickly</h2>
                    <div className='flex text-gray-400 py-3'>
                        <p className=' pr-5 border border-y-0 border-l-0'>Posted By <span className='text-black'>ADMIN</span></p>
                        <p className='pl-5'> March 2018 </p>
                    </div>
                    <p className='text-gray-400'>Lorem ipsum dolor sit amet, consectetur de adipisicing elit, sed do eiusmod tempore incididunt ut labore et dolore magna.</p>
                </div>
            </div>
            <div className='border w-[360px] shadow-lg hover:shadow-gray-500/50 shadow-black-500/50'>
                <img src="/public/Image/b3.jpg" alt="" />
                <div className='w-[350px] p-8'>
                    <h2>How to find your Desired Place more quickly</h2>
                    <div className='flex text-gray-400 py-3'>
                        <p className=' pr-5 border border-y-0 border-l-0'>Posted By <span className='text-black'>ADMIN</span></p>
                        <p className='pl-5'> March 2018 </p>
                    </div>
                    <p className='text-gray-400'>Lorem ipsum dolor sit amet, consectetur de adipisicing elit, sed do eiusmod tempore incididunt ut labore et dolore magna.</p>
                </div>
            </div>
          
        </div>
    </div>
  )
}
