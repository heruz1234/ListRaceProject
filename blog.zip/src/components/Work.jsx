import React from 'react'
import { FaRegLightbulb } from "react-icons/fa6";
export default function Work() {
  return (
    <div className=' text-center m-auto'>
      <h1 className='text-[#505866] text-2xl font-bold py-4'>HOW IT WORKS</h1>
      <p className='text-[#a09e9c]  py-3'>Learn More about how our website works</p>
      <div className='flex flex-wrap justify-between h-[400px] mt-10 mb-20 px-20'>
      
        <div className='py-[50px] px-[35px] border w-[350px] hover:bg-red-400 hover:text-white rounded-xl shadow-lg shadow-gray-500/70 '>
        <FaRegLightbulb className='bg-[rgb(128,128,128)] w-20 h-20 m-auto rounded-full p-5 hover:text-red-500 hover:bg-white'/>
          <h2 className='text-[#343a3f] text-2xl my-4'>Choose what to Do</h2>
          <p className='my-4'>Lorem ipsum dolor sit amet, consecte adipisicing elit, sed do eiusmod tempor incididunt ut laboremagna aliqua.</p>
          <button>Read More</button>
        </div>
        <div className='py-[50px]  px-[35px] border w-[350px] hover:bg-red-400 hover:text-white rounded-xl shadow-lg shadow-gray-500/70 '>
        <FaRegLightbulb className='bg-[gray] w-20 h-20 m-auto rounded-full p-4 hover:text-red-500 hover:bg-white'/>
          <h2 className='text-[#343a3f] text-2xl my-4'>Find what you want</h2>
          <p className='my-4'>Lorem ipsum dolor sit amet, consecte adipisicing elit, sed do eiusmod tempor incididunt ut laboremagna aliqua. </p>
          <button>Read More</button>
        </div>
        <div className='py-[50px]  px-[35px] border w-[350px] hover:bg-red-400 hover:text-white rounded-xl shadow-lg shadow-gray-500/70 '>
        <FaRegLightbulb className='bg-[gray] w-20 h-20 m-auto rounded-full p-4 hover:text-red-500 hover:bg-white'/>
          <h2 className='text-[#343a3f] text-2xl my-4'>Explore amazing Place </h2>
          <p className='my-4'>Lorem ipsum dolor sit amet, consecte adipisicing elit, sed do eiusmod tempor incididunt ut laboremagna aliqua.</p>
          <button>Read More</button>
        </div>
      </div>
    </div>
  )
}

