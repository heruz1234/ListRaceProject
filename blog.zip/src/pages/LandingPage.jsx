import React from 'react'
import Header from '../components/Header'
import Hero from '../components/Hero'
import Content from '../components/Content'
import Work from '../components/Work'
import Explore from '../components/Explore'
import Blog from '../components/Blog'
import Contact from '../components/Contact'
import Footer from '../components/Footer'
import Copyright from '../components/Copyright'
import Review from '../components/Review'


export default function LandingPage() {
  return (
    <div>
        <Header />
        <Hero />
        <Content />
        <Work />
        <Explore />
        <Review />
        <Blog />
        <Contact />
        <Footer />
        <Copyright />
    </div>
  )
}
