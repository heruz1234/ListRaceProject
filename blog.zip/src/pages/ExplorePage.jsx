import React from 'react'
import Explore from '../components/Explore'

export default function ExplorePage() {
  return (
    <div>
        <Explore />
    </div>
  )
}
