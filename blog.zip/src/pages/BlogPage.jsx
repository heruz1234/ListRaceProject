import React from 'react'
import Blog from '../components/Blog'

export default function BlogPage() {
  return (
    <div>
       <Blog />
    </div>
  )
}
