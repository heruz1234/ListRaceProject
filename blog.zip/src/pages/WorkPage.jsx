import React from 'react'
import Work from '../components/Work'

export default function WorkPage() {
  return (
    <div>
        <Work />
    </div>
  )
}
